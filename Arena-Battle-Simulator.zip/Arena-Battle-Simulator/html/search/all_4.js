var searchData=
[
  ['defeat_0',['defeat',['../classTeam.html#ac88f1e7d7b063ff012941551bbca383b',1,'Team']]],
  ['diceroll_1',['diceRoll',['../classDices.html#a60fb08535d0f7a40c704c6c41324637a',1,'Dices']]],
  ['dices_2',['Dices',['../classDices.html',1,'Dices'],['../classDices.html#ae9cfafeb4c467ef608ade4d859315242',1,'Dices::Dices()']]]
];
