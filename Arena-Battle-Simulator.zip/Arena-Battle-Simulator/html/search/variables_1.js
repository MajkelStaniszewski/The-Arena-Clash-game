var searchData=
[
  ['occupied_0',['occupied',['../structTile.html#a6bc8448a01a37db3dcb463d707c6c18e',1,'Tile']]]
];
