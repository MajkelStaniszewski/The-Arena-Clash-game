var searchData=
[
  ['_7egamemanager_0',['~GameManager',['../classGameManager.html#aaae63e38e358379c1fe507c5197a8435',1,'GameManager']]],
  ['_7egui_1',['~GUI',['../classGUI.html#ac9cae2328dcb5d83bdfaeca49a2eb695',1,'GUI']]]
];
