var searchData=
[
  ['player_0',['Player',['../classPlayer.html',1,'']]],
  ['postacie_1',['Postacie',['../classPostacie.html',1,'']]]
];
