var searchData=
[
  ['charakter_0',['Charakter',['../classCharakter.html',1,'']]]
];
