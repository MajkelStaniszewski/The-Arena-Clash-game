var searchData=
[
  ['isalive_0',['isAlive',['../classCharakter.html#acb7646d9523383254b3abb15dfea1bee',1,'Charakter::isAlive()'],['../classPostacie.html#a1acad96951e4d9ae8cf243293f95ccf6',1,'Postacie::isAlive()']]],
  ['istileoccupied_1',['isTileOccupied',['../classGameMap.html#ac3bdf81c66c646bffdc1bc5e9b641657',1,'GameMap']]]
];
