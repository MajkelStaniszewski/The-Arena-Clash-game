var searchData=
[
  ['postacie_0',['Postacie',['../classPostacie.html#a6e41e94032d33533f2da01334a660f47',1,'Postacie']]],
  ['printmap_1',['printMap',['../classGameMap.html#a01911bcb8921ad9f78acd1a84c50ef02',1,'GameMap']]]
];
