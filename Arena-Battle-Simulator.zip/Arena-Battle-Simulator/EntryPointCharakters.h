#ifndef ENTRYPOINTCHARAKTERS_H
#define ENTRYPOINTCHARAKTERS_H

#include "Charakter.h"

#include "Dragon.h"
#include "Knight.h"

#endif // ENTRYPOINTCHARAKTERS_H
