#ifndef MAP_H
#define MAP_H

class Map
{
public:
    Map();
    void printMap();
private:

};

#endif // MAP_H
